﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Slickflow.Module.Resource
{
    /// <summary>
    /// 角色ID列表查询
    /// </summary>
    public class RoleIDsQuery
    {
        public int[] RoleIDs { get; set; }
    }
}
