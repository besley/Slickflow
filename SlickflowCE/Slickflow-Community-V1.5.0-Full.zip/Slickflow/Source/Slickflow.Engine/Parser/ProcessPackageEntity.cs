﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Slickflow.Engine.Parser
{
    /// <summary>
    /// 流程Package实体
    /// </summary>
    public class ProcessPackageEntity
    {
        public string ProcessGUID { get; set; }
        public package package { get; set; }
    }
}
