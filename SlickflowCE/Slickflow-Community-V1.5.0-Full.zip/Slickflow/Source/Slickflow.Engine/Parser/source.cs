﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Slickflow.Engine.Parser
{
    /// <summary>
    /// 源类
    /// </summary>
    public class source
    {
        public int connectorIndex { get; set; }
        public int nodeId { get; set; }
    }
}
