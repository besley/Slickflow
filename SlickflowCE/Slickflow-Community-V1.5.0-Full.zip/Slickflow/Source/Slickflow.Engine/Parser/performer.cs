﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Slickflow.Engine.Parser
{
    /// <summary>
    /// 执行者类
    /// </summary>
    public class performer
    {
        public string id { get; set; }
    }
}
