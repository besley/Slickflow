﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Slickflow.Engine.Parser
{
    /// <summary>
    /// 条件类
    /// </summary>
    public class condition
    {
        public string type { get; set; }
        public string ConditionText { get; set; }
    }
}
