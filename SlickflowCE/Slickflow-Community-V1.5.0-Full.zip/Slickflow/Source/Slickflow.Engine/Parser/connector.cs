﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Slickflow.Engine.Parser
{
    /// <summary>
    /// 连接器类
    /// </summary>
    public class connector
    {
        public string type { get; set; }
        public int index { get; set; }
        public string name { get; set; }
    }
}
