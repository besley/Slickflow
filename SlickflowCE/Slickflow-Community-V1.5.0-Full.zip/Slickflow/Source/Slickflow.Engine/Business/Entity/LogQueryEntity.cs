﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Slickflow.Engine.Business.Entity
{
    /// <summary>
    /// 日志查询实体
    /// </summary>
    public class LogQueryEntity : QueryBase
    {
    }
}
