﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Slickflow.Engine.Common
{
    public enum CommentTypeEnum
    {
        Normal = 0
    }
}
