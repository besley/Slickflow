﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Slickflow.Engine.Common
{
    /// <summary>
    /// 常用定义类
    /// </summary>
    public class WfDefine
    {
        public const string WF_XPDL_ERROR = "XPDL定义错误";
        public const string WF_PROCESS_ERROR = "流程流转异常";
    }
}
