﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Slickflow.Module.Resource
{
    /// <summary>
    /// 流程定义包含的角色查询
    /// </summary>
    public class RoleQuery
    {
        public string ProcessGUID { get; set; }
        public string Version { get; set; }
    }
}
